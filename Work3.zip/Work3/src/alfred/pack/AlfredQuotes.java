
package alfred.pack;
import java.util.Date;
public class AlfredQuotes {

        public String basicGreeting() {
            return "Hello, lovely to see you. How are you?";
        }

        public String guestGreeting(String name, String hoursTime) {
            return String.format("Nice to meet you, %s,  % s is perfect timing of the day", name, hoursTime);
        }

        public String dateAnnouncement() {
            return String.format("Time at the moment is %s", new Date());
        }

        public String answeringBeforeAlexis(String phrase) {
            if(phrase.indexOf("Alexis") > -1) {
                return "What can i do for you?";
            }

            if (phrase.indexOf("Alfred") > -1) {
                return "At your service, naturally. How may I be of assistance?";
            }

            return "Right. thank you";
        }


    }