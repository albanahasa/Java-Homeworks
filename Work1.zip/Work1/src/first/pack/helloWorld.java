package first.pack;

public class helloWorld {
    public static void main(String[] str){
        System.out.println("My name is coding Dojo!");
        System.out.println("I am 100 years old");
        System.out.println("My home is Burbank, CA!");
    }
}

