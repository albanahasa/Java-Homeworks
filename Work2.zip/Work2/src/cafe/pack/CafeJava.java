package cafe.pack;
public class CafeJava {
    public static void main(String[] str) {
        String generalGreeting = "Welcome to Cafe Java, ";
        String pendingMessage = ", your order will be ready shortly";
        String readyMessage = ", your order is ready";
        String displayTotalMessage = "your total is $";


        double mochaPrice = 3.5;
        double cappucinoPrice = 4.6;
        double dripCoffeePrice = 2.1;
        double lattePrice = 3.2;

        String customer = "Cindhuri";
        String customer2 = "Noah";
        String customer3 = "Sam";
        String customer4 = "Jimmy";

        boolean isReadyOrder1 = false;
        boolean isReadyOrder2 = true;
        boolean isReadyOrder3 = false;
        boolean isReadyOrder4 = false;

        System.out.println(generalGreeting + customer);
        System.out.println(generalGreeting + customer2);
        System.out.println(generalGreeting + customer3);
        System.out.println(generalGreeting + customer4);
        System.out.println(customer2 + readyMessage);
        System.out.println(customer3 + readyMessage);
        System.out.println(customer4 + pendingMessage);
        System.out.println(customer + ",you ordered a coffe and " + displayTotalMessage + dripCoffeePrice);

        if (isReadyOrder2) {
            System.out.println(customer2 + pendingMessage);
        } else {
            System.out.println(customer2 + ",you ordered a cappucino and " + displayTotalMessage + cappucinoPrice);
        }
        if (isReadyOrder3) {
            System.out.println(customer3 + pendingMessage);
        } else {
            System.out.println(customer3 + ",you ordered 2 latte and " + displayTotalMessage + dripCoffeePrice);
        }
        System.out.println(displayTotalMessage + (lattePrice - dripCoffeePrice));

    }

}



